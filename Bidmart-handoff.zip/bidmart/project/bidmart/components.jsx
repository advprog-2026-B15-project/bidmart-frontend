// BidMart Prototype — shared components & icons
// Loads as classic script via Babel. Components attach to window.

const { useState, useEffect, useRef, useMemo } = React;

// =================================================================
// Icons — Lucide-style outline, stroke 1.75
// =================================================================
const ICO_BASE = { width: 20, height: 20, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 1.75, strokeLinecap: "round", strokeLinejoin: "round" };

const Icon = {
  Search:  (p) => <svg {...ICO_BASE} {...p}><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>,
  Heart:   (p) => <svg {...ICO_BASE} {...p}><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
  HeartFill:(p)=> <svg {...ICO_BASE} fill="currentColor" {...p}><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
  Bell:    (p) => <svg {...ICO_BASE} {...p}><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>,
  Wallet:  (p) => <svg {...ICO_BASE} {...p}><path d="M21 12V7a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-3"/><path d="M16 12h6"/><circle cx="18" cy="12" r="2"/></svg>,
  User:    (p) => <svg {...ICO_BASE} {...p}><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  Settings:(p) => <svg {...ICO_BASE} {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  Clock:   (p) => <svg {...ICO_BASE} {...p}><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>,
  Gavel:   (p) => <svg {...ICO_BASE} {...p}><path d="m14.5 12.5-8 8a2.12 2.12 0 1 1-3-3l8-8"/><path d="m16 16 6-6"/><path d="m8 8 6-6"/><path d="m9 7 8 8"/><path d="m21 11-8-8"/></svg>,
  Truck:   (p) => <svg {...ICO_BASE} {...p}><path d="M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2"/><path d="M15 18H9"/><path d="M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14"/><circle cx="17" cy="18" r="2"/><circle cx="7" cy="18" r="2"/></svg>,
  Star:    (p) => <svg {...ICO_BASE} {...p}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  StarFill:(p) => <svg {...ICO_BASE} fill="currentColor" {...p}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  Check:   (p) => <svg {...ICO_BASE} {...p}><polyline points="20 6 9 17 4 12"/></svg>,
  X:       (p) => <svg {...ICO_BASE} {...p}><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>,
  Chevron: (p) => <svg {...ICO_BASE} {...p}><polyline points="9 18 15 12 9 6"/></svg>,
  ChevronDown:(p)=><svg {...ICO_BASE} {...p}><polyline points="6 9 12 15 18 9"/></svg>,
  Plus:    (p) => <svg {...ICO_BASE} {...p}><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  Minus:   (p) => <svg {...ICO_BASE} {...p}><line x1="5" y1="12" x2="19" y2="12"/></svg>,
  Package: (p) => <svg {...ICO_BASE} {...p}><path d="M16.5 9.4 7.55 4.24"/><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>,
  Upload:  (p) => <svg {...ICO_BASE} {...p}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>,
  Image:   (p) => <svg {...ICO_BASE} {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>,
  Trophy:  (p) => <svg {...ICO_BASE} {...p}><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>,
  AlertTri:(p) => <svg {...ICO_BASE} {...p}><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>,
  Info:    (p) => <svg {...ICO_BASE} {...p}><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>,
  Eye:     (p) => <svg {...ICO_BASE} {...p}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>,
  EyeOff:  (p) => <svg {...ICO_BASE} {...p}><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>,
  LogOut:  (p) => <svg {...ICO_BASE} {...p}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
  TrendUp: (p) => <svg {...ICO_BASE} {...p}><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>,
  TrendDown:(p)=><svg {...ICO_BASE} {...p}><polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/></svg>,
  Users:   (p) => <svg {...ICO_BASE} {...p}><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  DollarSign:(p)=><svg {...ICO_BASE} {...p}><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>,
  Tag:     (p) => <svg {...ICO_BASE} {...p}><path d="M20.59 13.41 13.41 20.59a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.83Z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>,
  Filter:  (p) => <svg {...ICO_BASE} {...p}><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>,
  Shield:  (p) => <svg {...ICO_BASE} {...p}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
  Lock:    (p) => <svg {...ICO_BASE} {...p}><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>,
  CreditCard:(p)=><svg {...ICO_BASE} {...p}><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>,
  Calendar:(p) => <svg {...ICO_BASE} {...p}><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
  ArrowRight:(p)=><svg {...ICO_BASE} {...p}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>,
  ArrowDown:(p)=><svg {...ICO_BASE} {...p}><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>,
  ArrowUp: (p) => <svg {...ICO_BASE} {...p}><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></svg>,
  Refresh: (p) => <svg {...ICO_BASE} {...p}><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>,
  Home:    (p) => <svg {...ICO_BASE} {...p}><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
  List:    (p) => <svg {...ICO_BASE} {...p}><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
  Box:     (p) => <svg {...ICO_BASE} {...p}><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>,
  Flag:    (p) => <svg {...ICO_BASE} {...p}><path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/></svg>,
  Pencil:  (p) => <svg {...ICO_BASE} {...p}><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>,
  MoreH:   (p) => <svg {...ICO_BASE} {...p}><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></svg>,
  Cpu:     (p) => <svg {...ICO_BASE} {...p}><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/></svg>,
  Shirt:   (p) => <svg {...ICO_BASE} {...p}><path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/></svg>,
  Car:     (p) => <svg {...ICO_BASE} {...p}><path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2"/><circle cx="6.5" cy="16.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/></svg>,
  Sparkles:(p) => <svg {...ICO_BASE} {...p}><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3z"/></svg>,
  Trophy2: (p) => <svg {...ICO_BASE} {...p}><path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"/></svg>,
  Music:   (p) => <svg {...ICO_BASE} {...p}><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>,
  Gamepad: (p) => <svg {...ICO_BASE} {...p}><line x1="6" y1="12" x2="10" y2="12"/><line x1="8" y1="10" x2="8" y2="14"/><line x1="15" y1="13" x2="15.01" y2="13"/><line x1="18" y1="11" x2="18.01" y2="11"/><rect x="2" y="6" width="20" height="12" rx="2"/></svg>,
  Book:    (p) => <svg {...ICO_BASE} {...p}><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>,
  Palette: (p) => <svg {...ICO_BASE} {...p}><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>,
  Watch:   (p) => <svg {...ICO_BASE} {...p}><circle cx="12" cy="12" r="6"/><polyline points="12 10 12 12 13 13"/><path d="m16.13 7.66-.81-4.05a2 2 0 0 0-2-1.61h-2.68a2 2 0 0 0-2 1.61l-.78 4.05"/><path d="m7.88 16.36.8 4.05a2 2 0 0 0 2 1.59h2.72a2 2 0 0 0 2-1.61l.81-4.05"/></svg>,
  Grid:    (p) => <svg {...ICO_BASE} {...p}><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>,
};

// =================================================================
// Brand
// =================================================================
function Logo({ size = 22, inverse = false }) {
  return (
    <span className="bm-logo" style={{ fontSize: size, color: inverse ? "#fff" : undefined }}>
      Bid<span>Mart</span>
    </span>
  );
}

// =================================================================
// Button
// =================================================================
function Button({ variant = "primary", size = "md", children, leftIcon, ...rest }) {
  return (
    <button className={`bm-btn bm-btn-${variant} bm-btn-${size}`} {...rest}>
      {leftIcon}{children}
    </button>
  );
}

// =================================================================
// Badge
// =================================================================
function Badge({ tone = "blue", children, dot }) {
  return <span className={`bm-badge bm-badge-${tone}`}>{dot && <span className="bm-badge-dot"/>}{children}</span>;
}

// =================================================================
// Top Nav (Indonesian copy + user dropdown + wallet icon)
// =================================================================
function TopNav({ query, setQuery, onSearch, alerts = 3, goTo, currentPage }) {
  const [userOpen, setUserOpen] = useState(false);
  const userRef = useRef(null);
  useEffect(() => {
    const onDoc = (e) => { if (userRef.current && !userRef.current.contains(e.target)) setUserOpen(false); };
    document.addEventListener("click", onDoc); return () => document.removeEventListener("click", onDoc);
  }, []);
  return (
    <header className="bm-nav-wrap">
      <div className="bm-nav">
        <div className="bm-nav-brand" onClick={() => goTo("home")}>
          <Logo size={24}/>
        </div>
        <form
          className="bm-search"
          onSubmit={(e) => { e.preventDefault(); onSearch && onSearch(query); }}
        >
          <Icon.Search width={18} height={18}/>
          <input
            placeholder="Cari produk, brand, atau kategori"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          <select className="bm-search-cat" defaultValue="All">
            <option>Semua kategori</option>
            <option>Elektronik</option>
            <option>Fashion</option>
            <option>Otomotif</option>
            <option>Koleksi</option>
          </select>
          <button type="submit">Cari</button>
        </form>
        <div className="bm-nav-icons">
          <button className="bm-iconbtn" onClick={() => goTo("notifications")}>
            <span className="bm-iconbtn-wrap">
              <Icon.Bell/>
              {alerts > 0 && <span className="bm-iconbtn-badge">{alerts}</span>}
            </span>
            <span>Notifikasi</span>
          </button>
          <button className="bm-iconbtn" onClick={() => goTo("wallet")}>
            <Icon.Wallet/>
            <span>Dompet</span>
          </button>
          <div ref={userRef} style={{ position: "relative" }}>
            <button className="bm-userbtn" onClick={() => setUserOpen(o => !o)}>
              <span className="bm-avatar">AR</span>
              <span>Aulia</span>
              <Icon.ChevronDown width={14} height={14} style={{ color: "var(--ink-3)" }}/>
            </button>
            {userOpen && (
              <div className="bm-popover" onClick={() => setUserOpen(false)}>
                <div className="head">
                  <span className="bm-avatar lg">AR</span>
                  <div>
                    <div className="nm">Aulia Ramadhan</div>
                    <div className="em">aulia.r@gmail.com</div>
                  </div>
                </div>
                <div className="row" onClick={() => goTo("wallet")}><Icon.Wallet width={16} height={16}/>Dompet saya</div>
                <div className="row" onClick={() => goTo("orders")}><Icon.Package width={16} height={16}/>Pesanan</div>
                <div className="row" onClick={() => goTo("notifications")}><Icon.Bell width={16} height={16}/>Notifikasi</div>
                <div className="sep"/>
                <div className="row" onClick={() => goTo("create")}><Icon.Plus width={16} height={16}/>Jual barang</div>
                <div className="row" onClick={() => goTo("admin")}><Icon.Shield width={16} height={16}/>Admin dashboard</div>
                <div className="sep"/>
                <div className="row"><Icon.Settings width={16} height={16}/>Pengaturan akun</div>
                <div className="row danger" onClick={() => goTo("login")}><Icon.LogOut width={16} height={16}/>Keluar</div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Category pills horizontal scroller */}
      <div className="bm-page-wide">
        <div className="bm-catpills">
          {CAT_PILLS.map(c => {
            const IconC = Icon[c.icon] || Icon.Tag;
            const active = (currentPage === "home" && c.id === "all");
            return (
              <button key={c.id} className={`bm-catpill ${active ? "active" : ""}`}>
                <IconC width={14} height={14}/>{c.name}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
}

// =================================================================
// Auction Listing Card (Indonesian, IDR, live countdown)
// =================================================================
function AuctionCard({ item, onClick }) {
  const [watched, setWatched] = useState(false);
  const cd = useCountdown(item.ends);
  const urgent = cd.total < 2 * 60 * 1000 && cd.total > 0;
  const ended = cd.total <= 0;
  return (
    <div className="bm-listing" onClick={onClick}>
      <div className="bm-listing-image">
        <div className={`bm-listing-image-fill ${item.art}`}/>
        <button
          className={`bm-listing-heart ${watched ? "active" : ""}`}
          onClick={(e) => { e.stopPropagation(); setWatched(w => !w); }}
          aria-label="Watch this item"
        >
          {watched ? <Icon.HeartFill width={16} height={16}/> : <Icon.Heart width={16} height={16}/>}
        </button>
        {item.badge && !urgent && (
          <span className={`bm-listing-badge bm-listing-badge-${item.badge.tone}`}>{item.badge.text}</span>
        )}
        {urgent && (
          <span className="bm-listing-badge bm-listing-badge-red">BERAKHIR</span>
        )}
      </div>
      <div className="bm-listing-meta">
        <div className="bm-listing-title">{item.title}</div>
        <div className="bm-listing-price">{fmtRp(item.price)}</div>
        <div className="bm-listing-sub">
          <span className={urgent ? "urgent" : ""}>
            {ended ? "Lelang berakhir" : <CompactCountdown end={item.ends}/>}
          </span>
          <span> · {item.bids} bid</span>
        </div>
        <div className="bm-listing-sub" style={{ marginTop: 2 }}>
          oleh <span style={{ color: "var(--ink-2)", fontWeight: 500 }}>{item.seller}</span>
        </div>
      </div>
    </div>
  );
}

// =================================================================
// Countdown hook + compact display
// =================================================================
function useCountdown(endTimestamp) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  const ms = Math.max(0, endTimestamp - now);
  const s = Math.floor(ms/1000);
  const d_ = Math.floor(s/86400);
  const h_ = Math.floor((s%86400)/3600);
  const m_ = Math.floor((s%3600)/60);
  const sec = s%60;
  return { d: d_, h: h_, m: m_, s: sec, total: ms, urgent: ms < 2*60*1000 && ms > 0 };
}

function CompactCountdown({ end }) {
  const { d, h, m, s, total } = useCountdown(end);
  if (total <= 0) return <span>Berakhir</span>;
  if (d > 0) return <span>{d}h {h}j tersisa</span>;
  if (h > 0) return <span>{h}j {String(m).padStart(2,"0")}m tersisa</span>;
  if (m > 0) return <span>{m}m {String(s).padStart(2,"0")}d tersisa</span>;
  return <span>{s}d tersisa</span>;
}

function BlocksCountdown({ end }) {
  const { d, h, m, s, total } = useCountdown(end);
  const urgent = total < 2*60*1000 && total > 0;
  const safe   = total > 60*60*1000;
  if (total <= 0) {
    return <div className="bm-countdown-blocks"><span><b>00</b>h</span><span><b>00</b>m</span><span><b>00</b>d</span></div>;
  }
  return (
    <div className="bm-countdown-blocks" style={{ color: urgent ? "var(--red-600)" : (safe ? "var(--green-700)" : "var(--ink)") }}>
      {d > 0 && <span><b>{d}</b>h</span>}
      <span><b>{String(h).padStart(2,"0")}</b>j</span>
      <span><b>{String(m).padStart(2,"0")}</b>m</span>
      <span><b>{String(s).padStart(2,"0")}</b>d</span>
    </div>
  );
}

// =================================================================
// Star rating
// =================================================================
function StarRating({ rating, count }) {
  const full = Math.floor(rating);
  const half = (rating - full) >= 0.25 && (rating - full) < 0.75;
  return (
    <div className="bm-stars">
      {[0,1,2,3,4].map(i => (
        <Icon.StarFill key={i} width={13} height={13}
          style={{ color: i < full ? "#F5A623" : (i === full && half ? "#F5A623" : "var(--ink-4)") }}/>
      ))}
      <b>{rating.toFixed(2)}</b>
      {count != null && <span className="ct">({count.toLocaleString("id-ID")} ulasan)</span>}
    </div>
  );
}

// =================================================================
// Footer (Indonesian)
// =================================================================
function Footer() {
  const cols = [
    { title: "Beli",       links: ["Cara mendaftar", "Cara menawar", "Toko", "Kartu hadiah"] },
    { title: "Jual",       links: ["Mulai berjualan", "Belajar jualan", "Penjual bisnis", "Program afiliasi"] },
    { title: "Kepercayaan", links: ["Jaminan BidMart", "Standar penjual", "Keamanan", "Pusat resolusi"] },
    { title: "Tentang",    links: ["Perusahaan", "Berita", "Investor", "Karir"] },
  ];
  return (
    <footer className="bm-footer">
      <div className="bm-footer-inner">
        {cols.map(c => (
          <div className="bm-footer-col" key={c.title}>
            <div className="bm-footer-h">{c.title}</div>
            {c.links.map(l => <a key={l}>{l}</a>)}
          </div>
        ))}
      </div>
      <div className="bm-footer-base">
        <Logo size={18}/>
        <span>© 2026 BidMart Indonesia · Privasi · Syarat · Aksesibilitas</span>
      </div>
    </footer>
  );
}

// =================================================================
// Toast host
// =================================================================
function Toaster({ toasts, onDismiss }) {
  return (
    <div className="bm-toaster">
      {toasts.map(t => (
        <div key={t.id} className={`bm-toast bm-toast-${t.tone || "info"}`}>
          <div className="bm-toast-ico">{t.tone === "success" ? "✓" : t.tone === "error" ? "!" : "i"}</div>
          <div className="bm-toast-body">
            <div className="bm-toast-title">{t.title}</div>
            {t.desc && <div className="bm-toast-desc">{t.desc}</div>}
          </div>
          <button className="bm-toast-close" onClick={() => onDismiss(t.id)}>×</button>
        </div>
      ))}
    </div>
  );
}

// =================================================================
// Toggle Switch
// =================================================================
function Switch({ on, onChange }) {
  return <button className={`bm-switch ${on ? "on" : ""}`} onClick={() => onChange(!on)} aria-pressed={on}/>;
}

// =================================================================
// Screen switcher (top dark bar) — lets the reviewer jump between
// all 9 designed screens easily.
// =================================================================
function ScreenSwitcher({ page, setPage }) {
  const pages = [
    ["home",         "Beranda"],
    ["detail",       "Detail Lelang"],
    ["modal",        "Konfirmasi Bid"],
    ["wallet",       "Dompet"],
    ["login",        "Sign In / Register"],
    ["create",       "Buat Lelang"],
    ["orders",       "Pesanan"],
    ["notifications","Notifikasi"],
    ["admin",        "Admin Dashboard"],
  ];
  return (
    <div className="bm-screen-switcher">
      <span className="lbl">Prototype · {pages.length} screens</span>
      {pages.map(([id, label]) => (
        <button key={id} className={page === id ? "active" : ""} onClick={() => setPage(id)}>{label}</button>
      ))}
    </div>
  );
}

Object.assign(window, {
  Icon, Logo, Button, Badge, TopNav, AuctionCard,
  useCountdown, CompactCountdown, BlocksCountdown,
  StarRating, Footer, Toaster, Switch, ScreenSwitcher,
});
