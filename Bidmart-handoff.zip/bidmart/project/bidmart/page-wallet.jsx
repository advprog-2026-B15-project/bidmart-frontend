// BidMart Wallet

function WalletScreen({ goTo }) {
  const [typeFilter, setTypeFilter] = useState("All");
  const [page, setPage] = useState(1);
  const perPage = 8;

  const filtered = typeFilter === "All" ? TXNS : TXNS.filter(t => t.type === typeFilter);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));
  const slice = filtered.slice((page - 1) * perPage, page * perPage);

  const available = 18_420_000;
  const onHold = 4_250_000 + 27_000_000; // example bid holds

  const typeBadge = (t) => {
    const map = {
      "Top Up":   { tone: "green",  ico: <Icon.ArrowDown width={12} height={12}/> },
      "Bid Hold": { tone: "amber",  ico: <Icon.Gavel    width={12} height={12}/> },
      "Payment":  { tone: "blue",   ico: <Icon.CreditCard width={12} height={12}/> },
      "Refund":   { tone: "gray",   ico: <Icon.Refresh  width={12} height={12}/> },
      "Withdraw": { tone: "gray",   ico: <Icon.ArrowUp  width={12} height={12}/> },
    }[t] || { tone: "gray" };
    return (
      <span className={`bm-badge bm-badge-${map.tone}`}>
        {map.ico} {t}
      </span>
    );
  };

  return (
    <div className="bm-page-wide">
      <div className="bm-app">
        <AccountSideNav active="wallet" goTo={goTo}/>
        <div>
          <div className="bm-pg-head">
            <div>
              <h1>Dompet BidMart</h1>
              <p>Kelola saldo, top up, dan pantau riwayat transaksi kamu.</p>
            </div>
            <div className="bm-row" style={{ gap: 10 }}>
              <Button variant="secondary" size="md" leftIcon={<Icon.ArrowUp width={16} height={16}/>}>Tarik dana</Button>
              <Button variant="primary" size="md" leftIcon={<Icon.Plus width={16} height={16}/>}>Top Up</Button>
            </div>
          </div>

          {/* Stat cards */}
          <div className="bm-walletcards">
            <div className="bm-walletcard green">
              <div className="bm-walletcard-ico"><Icon.Wallet width={26} height={26}/></div>
              <div className="bm-walletcard-body">
                <div className="bm-walletcard-lbl">Saldo Tersedia</div>
                <div className="bm-walletcard-val">{fmtRp(available)}</div>
                <div className="bm-walletcard-sub">Terakhir top up: {fmtRp(5_000_000)} pada 18 Mei 2026, 06:14</div>
              </div>
            </div>
            <div className="bm-walletcard amber">
              <div className="bm-walletcard-ico"><Icon.Clock width={26} height={26}/></div>
              <div className="bm-walletcard-body">
                <div className="bm-walletcard-lbl">Sedang Ditahan</div>
                <div className="bm-walletcard-val">{fmtRp(onHold)}</div>
                <div className="bm-walletcard-sub">
                  Pada <b style={{ color: "#a07000" }}>2</b> lelang aktif —
                  dana otomatis kembali jika kamu disalip atau lelang berakhir.
                </div>
              </div>
            </div>
          </div>

          {/* Filters + table */}
          <div className="bm-pg-head" style={{ marginBottom: 14, alignItems: "flex-end" }}>
            <div>
              <h3 style={{ fontSize: 18, margin: 0 }}>Riwayat Transaksi</h3>
              <p style={{ color: "var(--ink-3)", fontSize: 13, marginTop: 4 }}>
                Menampilkan <b style={{ color: "var(--ink)" }}>{filtered.length}</b> dari {TXNS.length} transaksi
              </p>
            </div>
            <div className="bm-filterbar" style={{ margin: 0 }}>
              <select className="bm-select" value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setPage(1); }}>
                <option value="All">Semua tipe</option>
                <option value="Top Up">Top Up</option>
                <option value="Bid Hold">Bid Hold</option>
                <option value="Payment">Payment</option>
                <option value="Refund">Refund</option>
                <option value="Withdraw">Withdraw</option>
              </select>
              <select className="bm-select" defaultValue="30d">
                <option value="7d">7 hari terakhir</option>
                <option value="30d">30 hari terakhir</option>
                <option value="90d">90 hari terakhir</option>
                <option value="1y">12 bulan terakhir</option>
                <option value="all">Semua waktu</option>
              </select>
              <Button variant="ghost" size="md" leftIcon={<Icon.Filter width={14} height={14}/>}>Filter lain</Button>
            </div>
          </div>

          <div className="bm-table-wrap">
            <table className="bm-table">
              <thead>
                <tr>
                  <th style={{ width: 160 }}>Tanggal</th>
                  <th style={{ width: 130 }}>Tipe</th>
                  <th>Deskripsi</th>
                  <th style={{ width: 160, textAlign: "right" }}>Jumlah</th>
                  <th style={{ width: 140, textAlign: "right" }}>Saldo</th>
                </tr>
              </thead>
              <tbody>
                {slice.map((t, i) => (
                  <tr key={i}>
                    <td style={{ color: "var(--ink-2)" }}>{t.date}</td>
                    <td>{typeBadge(t.type)}</td>
                    <td style={{ color: "var(--ink)" }}>{t.desc}</td>
                    <td style={{ textAlign: "right" }} className={t.amount >= 0 ? "pos" : "neg"}>
                      {t.amount >= 0 ? "+" : "−"}{fmtRp(Math.abs(t.amount))}
                    </td>
                    <td style={{ textAlign: "right", color: "var(--ink)" }}>{fmtRp(t.balance)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bm-pagination">
            <span>Menampilkan {(page-1)*perPage + 1}–{Math.min(page*perPage, filtered.length)} dari {filtered.length}</span>
            <div className="pages">
              <button className="pg" disabled={page === 1} onClick={() => setPage(p => Math.max(1, p-1))}>
                <Icon.Chevron width={14} height={14} style={{ transform: "rotate(180deg)" }}/>
              </button>
              {Array.from({ length: totalPages }).map((_, i) => (
                <button key={i} className={`pg ${page === i+1 ? "active" : ""}`} onClick={() => setPage(i+1)}>
                  {i+1}
                </button>
              ))}
              <button className="pg" disabled={page === totalPages} onClick={() => setPage(p => Math.min(totalPages, p+1))}>
                <Icon.Chevron width={14} height={14}/>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Shared side nav for account-internal pages
function AccountSideNav({ active, goTo }) {
  const items = [
    { group: "Aktivitas" },
    { id: "orders",        label: "Pesanan",      ico: <Icon.Package width={16} height={16}/>, badge: 4, page: "orders" },
    { id: "watchlist",     label: "Watchlist",    ico: <Icon.Heart width={16} height={16}/>, badge: 12 },
    { id: "bidding",       label: "Sedang menawar", ico: <Icon.Gavel width={16} height={16}/>, badge: 2 },
    { id: "notifications", label: "Notifikasi",   ico: <Icon.Bell width={16} height={16}/>, badge: 3, page: "notifications" },

    { group: "Keuangan" },
    { id: "wallet",        label: "Dompet",       ico: <Icon.Wallet width={16} height={16}/>, page: "wallet" },
    { id: "payment",       label: "Metode bayar", ico: <Icon.CreditCard width={16} height={16}/> },

    { group: "Jualan" },
    { id: "listings",      label: "Listing saya", ico: <Icon.List width={16} height={16}/>, badge: 7 },
    { id: "create",        label: "Buat lelang baru", ico: <Icon.Plus width={16} height={16}/>, page: "create" },
    { id: "sales",         label: "Penjualan",    ico: <Icon.TrendUp width={16} height={16}/> },

    { group: "Akun" },
    { id: "profile",       label: "Profil",       ico: <Icon.User width={16} height={16}/> },
    { id: "security",      label: "Keamanan",     ico: <Icon.Lock width={16} height={16}/> },
    { id: "settings",      label: "Pengaturan",   ico: <Icon.Settings width={16} height={16}/> },
  ];
  return (
    <nav className="bm-sidenav">
      {items.map((it, i) => (
        it.group
          ? <div key={"g"+i} className="bm-sidenav-h">{it.group}</div>
          : <button key={it.id}
              className={`bm-sidenav-item ${active === it.id ? "active" : ""}`}
              onClick={() => it.page && goTo(it.page)}>
              {it.ico}{it.label}
              {it.badge && <span className="pill">{it.badge}</span>}
            </button>
      ))}
    </nav>
  );
}

Object.assign(window, { WalletScreen, AccountSideNav });
