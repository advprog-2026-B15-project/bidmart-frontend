// BidMart — Bid Confirmation Modal

function BidConfirmModal({ open, item, bidAmount, onClose, onConfirm }) {
  if (!open || !item) return null;
  const fee = Math.round(bidAmount * 0.02);
  const total = bidAmount + fee;
  return (
    <div className="bm-modal-backdrop" onClick={onClose}>
      <div className="bm-modal" onClick={(e) => e.stopPropagation()}>
        <div className="bm-modal-head">
          <h3>Konfirmasi tawaran kamu</h3>
          <button className="bm-modal-close" onClick={onClose}><Icon.X width={20} height={20}/></button>
        </div>

        <div className="bm-modal-body">
          {/* Item summary */}
          <div className="bm-modal-item">
            <div className="bm-modal-item-thumb">
              <div className={item.art}/>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div className="bm-modal-item-title">{item.title}</div>
              <div className="bm-modal-item-meta">
                Sisa <CompactCountdown end={item.ends}/> · {item.bids} bid · oleh {item.seller}
              </div>
            </div>
          </div>

          {/* Bid amount summary */}
          <div className="bm-modal-amount">
            <div className="row">
              <span className="lbl">Tawaran kamu</span>
              <span className="big">{fmtRp(bidAmount)}</span>
            </div>
            <div className="row">
              <span className="lbl" style={{ textTransform: "none", letterSpacing: 0, fontWeight: 500, color: "var(--ink-2)" }}>Tertinggi saat ini</span>
              <span className="small">{fmtRp(item.price)}</span>
            </div>
            <div className="row">
              <span className="lbl" style={{ textTransform: "none", letterSpacing: 0, fontWeight: 500, color: "var(--ink-2)" }}>Biaya layanan (2%)</span>
              <span className="small">{fmtRp(fee)}</span>
            </div>
          </div>

          {/* Hold notice */}
          <div className="bm-modal-hold">
            <Icon.Wallet width={18} height={18}/>
            <div>
              <b>{fmtRp(total)}</b> akan ditahan sementara dari dompet kamu hingga lelang berakhir.
              Jika kamu disalip, dana akan dikembalikan otomatis.
            </div>
          </div>
        </div>

        <div className="bm-modal-fine">
          Dengan menawar, kamu setuju untuk membeli barang ini jika menang. Tawaran tidak dapat dibatalkan setelah dikirim.
        </div>

        <div className="bm-modal-foot">
          <Button variant="secondary" size="lg" onClick={onClose}>Batal</Button>
          <Button variant="primary" size="lg" onClick={onConfirm}>
            <Icon.Gavel width={16} height={16}/> Konfirmasi tawaran
          </Button>
        </div>
      </div>
    </div>
  );
}

// Standalone preview view for the modal screen (shows it in context)
function ModalScreenPreview({ goTo }) {
  const item = ITEMS[0];
  const bidAmount = item.price + 150_000;
  return (
    <div style={{ position: "relative", minHeight: "calc(100vh - 110px)" }}>
      {/* Dim the page behind by rendering a faux detail surface */}
      <div className="bm-page-wide" style={{ pointerEvents: "none", filter: "blur(0.5px)", opacity: 0.55 }}>
        <nav className="bm-bread">
          <a>Beranda</a><span className="sep">/</span><a>Elektronik</a><span className="sep">/</span><span className="here">Sony WH-1000XM5…</span>
        </nav>
        <div className="bm-detail">
          <div className="bm-gallery">
            <div className="bm-gallery-main">
              <div className={`bm-gallery-main-art ${item.art}`}/>
            </div>
            <div className="bm-gallery-thumbs">
              {[0,1,2,3].map(i => (
                <div key={i} className="bm-gallery-thumb">
                  <div className={`bm-gallery-thumb-art ${item.art}`}/>
                </div>
              ))}
            </div>
          </div>
          <div className="bm-detail-info">
            <h1 className="bm-detail-title">{item.title}</h1>
            <div className="bm-bid-panel">
              <div className="bm-bid-price-big">{fmtRp(item.price)}</div>
              <BlocksCountdown end={item.ends}/>
            </div>
          </div>
        </div>
      </div>

      {/* Modal mounted over */}
      <BidConfirmModal
        open={true}
        item={item}
        bidAmount={bidAmount}
        onClose={() => goTo("detail")}
        onConfirm={() => goTo("detail")}
      />
    </div>
  );
}

Object.assign(window, { BidConfirmModal, ModalScreenPreview });
